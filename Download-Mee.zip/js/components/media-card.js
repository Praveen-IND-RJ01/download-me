function createMediaCard(item,type){
    const card=document.createElement("article");
    card.className="media-card";
    card.innerHTML=`<img class="media-card__image" src="${item.poster}" alt="${item.title} poster" loading="lazy">
    <div class="media-card__body"><h3 class="media-card__title">${item.title}</h3>
    <p class="media-card__meta">${item.year} • ${item.genre}</p></div>`;
    card.addEventListener("click",()=>location.href=`pages/detail.html?type=${type}&id=${item.id}`);
    return card;
}
