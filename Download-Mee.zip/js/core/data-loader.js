async function loadJson(path){
    const response=await fetch(path);
    if(!response.ok) throw new Error(`Could not load JSON: ${path}`);
    return response.json();
}
function getQueryParameter(name){return new URLSearchParams(location.search).get(name)}
function redirectHome(){location.replace("../index.html")}
function visibilityKey(id){return id}
function isVisible(item){
    const o=JSON.parse(localStorage.getItem("downloadMeVisibility")||"{}");
    return Object.prototype.hasOwnProperty.call(o,visibilityKey(item.id))
        ? o[visibilityKey(item.id)]===true
        : item.enabled===true;
}
