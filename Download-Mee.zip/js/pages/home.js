async function initializeHomePage(){
    const [movieData,dramaData,animeData]=await Promise.all([
        loadJson("data/movies.json"),loadJson("data/dramas.json"),loadJson("data/anime.json")
    ]);
    const movieGrid=document.getElementById("movieGrid"), dramaGrid=document.getElementById("dramaGrid"), animeGrid=document.getElementById("animeGrid");
    const movieCount=document.getElementById("movieCount"), dramaCount=document.getElementById("dramaCount"), animeCount=document.getElementById("animeCount");
    const movies=movieData.movies.filter(isVisible), dramas=dramaData.dramas.filter(isVisible), anime=animeData.anime.filter(isVisible);

    function render(grid,list,type,count){grid.replaceChildren();list.forEach(x=>grid.appendChild(createMediaCard(x,type)));count.textContent=`${list.length} available`;}
    render(movieGrid,movies,"movie",movieCount);render(dramaGrid,dramas,"drama",dramaCount);render(animeGrid,anime,"anime",animeCount);

    document.getElementById("siteSearch").addEventListener("input",e=>{
        const q=e.target.value.toLowerCase().trim();
        render(movieGrid,movies.filter(x=>`${x.title} ${x.genre}`.toLowerCase().includes(q)),"movie",movieCount);
        render(dramaGrid,dramas.filter(x=>`${x.title} ${x.genre}`.toLowerCase().includes(q)),"drama",dramaCount);
        render(animeGrid,anime.filter(x=>`${x.title} ${x.genre}`.toLowerCase().includes(q)),"anime",animeCount);
    });
}
initializeHomePage().catch(console.error);
