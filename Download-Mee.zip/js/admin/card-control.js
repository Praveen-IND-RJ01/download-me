const KEY="downloadMeVisibility";
const overrides=()=>JSON.parse(localStorage.getItem(KEY)||"{}");
const save=o=>localStorage.setItem(KEY,JSON.stringify(o));
const state=(id,def)=>Object.prototype.hasOwnProperty.call(overrides(),id)?overrides()[id]:def===true;
function toggle(id){const o=overrides();o[id]=!state(id,true);save(o);render();}
function row(name,type,id,enabled){
    const r=document.createElement("div");r.className="item";
    r.innerHTML=`<div><strong>${name}</strong><br><small>${type} • ${id}</small></div>`;
    const b=document.createElement("button");b.className=`toggle ${enabled?"on":"off"}`;b.textContent=enabled?"ENABLED":"DISABLED";
    b.onclick=()=>toggle(id);r.appendChild(b);return r;
}
async function render(){
    const root=document.getElementById("controls");root.replaceChildren();
    const [m,d,a]=await Promise.all([loadJson("../data/movies.json"),loadJson("../data/dramas.json"),loadJson("../data/anime.json")]);

    const ms=document.createElement("section");ms.className="group";ms.innerHTML="<h2>Movies — 10 Cards</h2>";
    m.movies.forEach(x=>ms.appendChild(row(x.title,"Movie card",x.id,state(x.id,x.enabled))));root.appendChild(ms);

    for(const drama of d.dramas){
        const s=document.createElement("section");s.className="group";s.innerHTML=`<h2>${drama.title}</h2>`;
        s.appendChild(row(`${drama.title} Card`,"Drama card",drama.id,state(drama.id,drama.enabled)));
        const data=await loadJson(`../${drama.episodesFile}`), nested=document.createElement("div");nested.className="nested";
        data.seasons.forEach(season=>{
            const sk=`${drama.id}::${season.id}`;nested.appendChild(row(season.name,"Season",sk,state(sk,season.enabled)));
            const epbox=document.createElement("div");epbox.className="nested";
            season.episodes.forEach(ep=>{const ek=`${drama.id}::${season.id}::${ep.id}`;epbox.appendChild(row(ep.title,"Episode",ek,state(ek,ep.enabled)))});
            nested.appendChild(epbox);
        });s.appendChild(nested);root.appendChild(s);
    }

    const as=document.createElement("section");as.className="group";as.innerHTML="<h2>Anime — 10 Cards</h2>";
    for(const anime of a.anime){
        as.appendChild(row(anime.title,"Anime card",anime.id,state(anime.id,anime.enabled)));
        const data=await loadJson(`../${anime.episodesFile}`), epbox=document.createElement("div");epbox.className="nested";
        data.episodes.forEach(ep=>{const ek=`${anime.id}::${ep.id}`;epbox.appendChild(row(ep.title,"Anime episode",ek,state(ek,ep.enabled)))});
        as.appendChild(epbox);
    }
    root.appendChild(as);
    document.getElementById("status").textContent="Saved on this browser";
}
async function setAll(value){
    const [m,d,a]=await Promise.all([loadJson("../data/movies.json"),loadJson("../data/dramas.json"),loadJson("../data/anime.json")]),o=overrides();
    m.movies.forEach(x=>o[x.id]=value);a.anime.forEach(x=>o[x.id]=value);
    for(const drama of d.dramas){o[drama.id]=value;const data=await loadJson(`../${drama.episodesFile}`);data.seasons.forEach(s=>{o[`${drama.id}::${s.id}`]=value;s.episodes.forEach(e=>o[`${drama.id}::${s.id}::${e.id}`]=value)})}
    for(const anime of a.anime){const data=await loadJson(`../${anime.episodesFile}`);data.episodes.forEach(e=>o[`${anime.id}::${e.id}`]=value)}
    save(o);render();
}
document.getElementById("enable").onclick=()=>setAll(true);
document.getElementById("disable").onclick=()=>setAll(false);
document.getElementById("reset").onclick=()=>{localStorage.removeItem(KEY);render()};
render().catch(console.error);
