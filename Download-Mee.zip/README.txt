DOWNLOAD ME V8

SECTIONS
1. Movies — 10 cards
2. Dramas — 4 cards
3. Anime — 10 cards

ANIME DATA
data/anime.json
data/anime/anime1.json ... anime10.json

Each anime has EP 1–24 with 480p and 720p links.

CARD CONTROL
admin/card-control.html

The control page can enable/disable:
- movie cards
- drama cards
- drama seasons
- drama episodes
- anime cards
- anime episodes

Disabled items are not rendered on the public home/detail/download flow.

IMPORTANT
This static version stores overrides in browser localStorage. It is not a
secure server-side admin panel and does not modify JSON files. For a real
production site, use authenticated server-side storage.

MEDIA LINKS
The example.com URLs are placeholders. Replace them only with content you
are authorized to distribute.


ZIP DOWNLOADS
For anime and drama entries, data/anime.json and data/dramas.json now support:
zipDownloads.direct = direct ZIP URL
zipDownloads.pixeldrain = PixelDrain ZIP URL
Replace the example.com and REPLACE_* values with your own authorized ZIP links.
