async function initializeDetail(){
    const type=getQueryParameter("type"), id=getQueryParameter("id"), page=document.getElementById("detailPage");
    if(!["movie","drama","anime"].includes(type)) return redirectHome();

    const file=type==="movie"?"../data/movies.json":type==="drama"?"../data/dramas.json":"../data/anime.json";
    const key=type==="movie"?"movies":type==="drama"?"dramas":"anime";
    const catalog=await loadJson(file);
    const item=catalog[key].find(x=>x.id===id && isVisible(x));
    if(!item) return redirectHome();

    document.title=`${item.title} | Download Me`;
    let body=`<div class="detail-meta">${item.year} • ${item.genre}</div><h1>${item.title}</h1><p>Select a quality or episode.</p>`;

    if(type==="movie"){
        body+=`<a class="quality-button" href="download.html?type=movie&id=${item.id}&quality=480p">480p</a>
        <a class="quality-button" href="download.html?type=movie&id=${item.id}&quality=720p">720p</a>`;
    }else{
        const zip=item.zipDownloads || {};
        body+=`<section class="zip-download-box">
            <div>
                <span class="zip-download-label">${type==="anime" ? "ANIME" : "DRAMA"} ZIP DOWNLOAD</span>
                <h2>Download Complete ZIP</h2>
                <p>Choose your preferred ZIP hosting option.</p>
            </div>
            <div class="zip-download-actions">
                ${zip.direct ? `<a class="zip-button zip-button--direct" href="${zip.direct}" target="_blank" rel="noopener noreferrer">Direct ZIP</a>` : ""}
                ${zip.pixeldrain ? `<a class="zip-button zip-button--pixeldrain" href="${zip.pixeldrain}" target="_blank" rel="noopener noreferrer">PixelDrain ZIP</a>` : ""}
            </div>
        </section>`;

        const data=await loadJson(`../${item.episodesFile}`);
        body+=`<div class="season-grid">${type==="drama"
            ? data.seasons.filter(isVisible).map(s=>`<article class="season-card"><h3>${s.name}</h3><div class="episode-grid">${
                s.episodes.filter(isVisible).map(e=>`<a class="episode-link" href="download.html?type=episode&content=${type}&id=${item.id}&season=${s.id}&episode=${e.number}">EP ${e.number}</a>`).join("")
            }</div></article>`).join("")
            : `<article class="season-card"><h3>Episodes</h3><div class="episode-grid">${
                data.episodes.filter(isVisible).map(e=>`<a class="episode-link" href="download.html?type=episode&content=anime&id=${item.id}&episode=${e.number}">EP ${e.number}</a>`).join("")
            }</div></article>`}</div>`;
    }

    page.innerHTML=`<section class="detail-hero" style="background-image:url('${item.backdrop}')"><div class="detail-hero__overlay"></div>
    <div class="detail-content">${body}</div></section>`;
}
initializeDetail().catch(console.error);
