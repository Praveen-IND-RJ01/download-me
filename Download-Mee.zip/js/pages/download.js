async function initializeDownload(){
    const type=getQueryParameter("type");
    if(type==="movie") return movieDownload();
    if(type==="episode") return episodeDownload();
    redirectHome();
}
async function movieDownload(){
    const id=getQueryParameter("id"), quality=getQueryParameter("quality"), data=await loadJson("../data/movies.json");
    const item=data.movies.find(x=>x.id===id && isVisible(x));
    if(!item || !item.downloads[quality]) return redirectHome();
    document.getElementById("backLink").href=`detail.html?type=movie&id=${id}`;
    document.getElementById("downloadPage").innerHTML=`<section class="download-page"><div class="download-card">
    <img class="download-card__poster" src="${item.poster}" alt="${item.title}">
    <div class="download-card__content"><div class="detail-meta">MOVIE DOWNLOAD</div><h1>${item.title}</h1><p>Selected quality: <strong>${quality}</strong></p>
    <a class="download-action" href="${item.downloads[quality]}" target="_blank" rel="noopener noreferrer">Download ${quality}</a></div></div></section>`;
}
async function episodeDownload(){
    const content=getQueryParameter("content"), id=getQueryParameter("id"), epNo=Number(getQueryParameter("episode"));
    const file=content==="drama"?"../data/dramas.json":"../data/anime.json", key=content==="drama"?"dramas":"anime";
    const catalog=await loadJson(file), item=catalog[key].find(x=>x.id===id && isVisible(x));
    if(!item) return redirectHome();
    const data=await loadJson(`../${item.episodesFile}`);
    let ep, back=`detail.html?type=${content}&id=${id}`;
    if(content==="drama"){
        const season=data.seasons.find(s=>s.id===getQueryParameter("season") && isVisible(s));
        ep=season?.episodes.find(e=>e.number===epNo && isVisible(e));
    }else ep=data.episodes.find(e=>e.number===epNo && isVisible(e));
    if(!ep) return redirectHome();
    document.getElementById("backLink").href=back;
    document.getElementById("downloadPage").innerHTML=`<section class="download-page"><div class="download-card">
    <img class="download-card__poster" src="${item.poster}" alt="${item.title}">
    <div class="download-card__content"><div class="detail-meta">${item.title}</div><h1>${ep.title}</h1><p>Select your quality.</p>
    <a class="download-action" href="${ep.downloads["480p"]}" target="_blank" rel="noopener noreferrer">480p</a>
    <a class="download-action" href="${ep.downloads["720p"]}" target="_blank" rel="noopener noreferrer">720p</a></div></div></section>`;
}
initializeDownload().catch(console.error);
